package servlet;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/new")
public class MyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final Logger logger = LogManager.getLogger(MyServlet.class);

    // Database connection details
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/auca";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "078868";

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        logger.info("Entered GET method");

        String theId = request.getParameter("id");
        if (theId == null || !theId.matches("\\d+")) {
            logger.error("Invalid ID: " + theId);
            response.sendRedirect("studentForm.html");
            response.getWriter().print("<h1>Id Invalid</h1>");
            return;
        }

        Integer id = Integer.parseInt(theId);

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pst = con.prepareStatement("SELECT * FROM students WHERE id = ?")) {
             
            pst.setInt(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String lname = rs.getString("lname");
                    logger.info("Name: " + lname + ", ID: " + id);
                    response.getWriter().print("<h1>The name is " + lname + " and ID is " + id + "</h1>");
                } else {
                    logger.info("ID " + id + " does not exist.");
                    response.getWriter().print("<h1>Id does not exist</h1>");
                }
            }
        } catch (SQLException e) {
            logger.error("SQL exception: " + e.getMessage(), e);
            response.getWriter().print("<h1>Database error occurred</h1>");
        } catch (ClassNotFoundException e) {
            logger.error("Class not found: " + e.getMessage(), e);
            response.getWriter().print("<h1>Server error occurred</h1>");
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        logger.info("Entered POST method");

        String name = request.getParameter("name");
        String id = request.getParameter("id");

        if (id == null || !id.matches("\\d+")) {
            logger.warn("Invalid ID: " + id);
            response.sendRedirect("studentForm.html");
            response.getWriter().print("<h1>Id must be an integer</h1>");
            return;
        }

        Integer theId = Integer.parseInt(id);

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pst = con.prepareStatement("INSERT INTO students (id, lname) VALUES (?, ?)")) {
             
            pst.setInt(1, theId);
            pst.setString(2, name);
            int rowsAffected = pst.executeUpdate();
            
            if (rowsAffected > 0) {
                logger.info("Inserted data into database. ID: " + theId + ", Name: " + name);
                response.getWriter().print("<h1>Inserted successfully</h1>");
            } else {
                logger.error("Insert failed for ID: " + theId);
                response.getWriter().print("<h1>Insert Failed</h1>");
            }
        } catch (SQLException e) {
            logger.error("SQL exception: " + e.getMessage(), e);
            response.getWriter().print("<h1>Database error occurred</h1>");
        } catch (ClassNotFoundException e) {
            logger.error("Class not found: " + e.getMessage(), e);
            response.getWriter().print("<h1>Server error occurred</h1>");
        }
    }
}

