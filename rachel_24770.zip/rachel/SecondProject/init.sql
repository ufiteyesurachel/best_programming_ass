-- init.sql

CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    lname VARCHAR(50) NOT NULL
);
